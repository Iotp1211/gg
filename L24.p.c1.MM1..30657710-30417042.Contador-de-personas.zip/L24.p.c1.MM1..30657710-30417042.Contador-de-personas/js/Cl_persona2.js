export default class Cl_persona2 {
    constructor () {
        this.contM = 0;
        this.contF = 0;
    }
    procesarPersona(p){
        if (p.sexo == 'M') {
            this.contM++;
        } else if (p.sexo == 'F') {
            this.contF++;
        }
    }
    totalPersonas() {
        return this.contM + this.contF;
    }
}