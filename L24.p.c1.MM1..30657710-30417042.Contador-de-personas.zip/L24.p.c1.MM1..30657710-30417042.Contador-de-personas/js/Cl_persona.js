export default class Cl_persona {
    constructor (nombre, sexo) {
        this.nombre = nombre;
        this.sexo = sexo;
    }
    calcularsexo () {
    switch (this.sexo) {
        case 'M':
            return 'hombre'
        case 'F':
            return 'mujer'
        }
    }
}