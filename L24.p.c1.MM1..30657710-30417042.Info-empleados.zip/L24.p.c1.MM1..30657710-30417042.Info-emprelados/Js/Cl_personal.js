export default class Cl_personal{
    constructor (nombre, tipoPersonal, sueldo){
        this.nombre = nombre;
        this.tipoPersonal = tipoPersonal;
    }
    tipo(){
        if (this.tipoPersonal == "Obrero"){
            return "obrero";
        }
        else if (this.tipoPersonal === "Administrativo"){
            return "administrativo";
        }
    }
}