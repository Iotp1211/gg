/**
 *En una empresa se tiene personal obrero y personal administrativo. La empresa necesita 
determinar cuál es el monto promedio que paga por cada tipo de personal.

Al ser consultada por la forma como desean que se presente la salida, la empresa suministra 
el siguiente formato, informando que Juan (obrero) actualmente gana $100, Ana (obrero) gana 
$120, Lin (administrativo) gana $200, Mary (obrero) gana $50 y Carlos (administrativo) 
gana $150:

Monto total pagado a obreros: $270 
Promedio pagado a 3 obreros: $90 
Monto total pagado a administrativos: $350 
Promedio pagado a 2 administrativos: $175
 */

import Cl_Empresa from "./Cl_Empresa.js"
import Cl_personal from "./Cl_personal.js"

let empresa = new Cl_Empresa();

trabajador1 = new Cl_personal("Juan", "Obrero", 100),
trabajador2 = new Cl_personal("Ana", "Obrero", 120),
trabajador3 = new Cl_personal("Lin", "Administrativo", 200),
trabajador4 = new Cl_personal("Mary", "Obrero", 50),
trabajador5 = new Cl_personal("Carlos", "Administrativo", 150);

empresa.procesarPersonal(trabajador1),
empresa.procesarPersonal(trabajador2),
empresa.procesarPersonal(trabajador3),
empresa.procesarPersonal(trabajador4),
empresa.procesarPersonal(trabajador5);


let salida = document.getElementById("salida");
salida.innerHTML = `
<p>Monto total pagado a obreros: 270$</p>
<p>Promedio pagado a 3 obreros: ${empresa.promedioObrero()}$</p>
<p>Monto total pagado a administrativos: 350$</p>
<p>Promedio pagado a 2 administrativos: ${empresa.promedioAdministrativo()}$</p>
`;