import Cl_personal from "./Cl_personal.js"
export default class Cl_Empresa{
    constructor (){
        this.cntObreros =
        this.cntAdministrativos =
        0;
    }
    procesarPersonal(p){
        if (p._tipoPersonal == "obrero"){
            cntObreros++;
        }
        else if (p._tipoPersonal == "administrativo"){
            cntAdministrativos++;
        }
    }
    promedioObrero(){
        return ( 270/ this.cntAdministrativos);
    }
    promedioAdministrativo(){
        return ( 350/ this.cntAdministrativos);
    }
}